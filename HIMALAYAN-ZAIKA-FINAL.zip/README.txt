HIMALAYAN ZAIKA — FINAL WEBSITE PACKAGE

Main file:
- index.html

Supabase project is already configured in the frontend.
This package contains the final combined frontend version with booking,
OTP login, manager dashboard, room inventory, room allotment, booking
status lookup, galleries and admin controls.

Upload the contents of this ZIP to your static hosting root.
